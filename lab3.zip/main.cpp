// Copyright 2026 Upi52
#include <iostream>
#include "Automata.h"

int main() {
    Automata a;

    std::cout << "--- Включение автомата ---" << std::endl;
    a.on();
    std::cout << "Состояние: " << a.getStateName() << std::endl;

    std::cout << "\n=== Меню ===" << std::endl;
    auto m = a.getMenu();
    for (size_t i = 0; i < m.size(); ++i)
        std::cout << i + 1 << ". " << m[i]
                  << " - " << a.prices[i] << " руб." << std::endl;

    std::cout << "\n--- Сценарий 1: успешная покупка кофе ---" << std::endl;
    a.coin(30);
    std::cout << "Внесено 30 руб. Состояние: " << a.getStateName() << std::endl;
    a.coin(30);
    std::cout << "Внесено ещё 30 руб. Итого: " << a.cash << " руб." << std::endl;
    a.choice(0);
    std::cout << "Выбран кофе. Состояние: " << a.getStateName() << std::endl;
    if (a.check()) {
        a.cook();
        std::cout << "Состояние после приготовления: " << a.getStateName() << std::endl;
        a.finish();
    } else {
        a.cancel();
    }
    std::cout << "Состояние: " << a.getStateName() << std::endl;

    std::cout << "\n--- Сценарий 2: недостаточно денег, отмена и повтор ---" << std::endl;
    a.coin(10);
    a.choice(0);
    if (a.check()) {
        a.cook();
        a.finish();
    } else {
        std::cout << "Недостаточно средств. Нужно ещё: "
                  << a.prices[a.selectedDrink] - a.cash << " руб." << std::endl;
        a.cancel();
        a.coin(60);
        std::cout << "Внесено 60 руб. Состояние: " << a.getStateName() << std::endl;
        a.choice(0);
        if (a.check()) {
            a.cook();
            a.finish();
        }
    }
    std::cout << "Состояние: " << a.getStateName() << std::endl;

    std::cout << "\n--- Сценарий 3: отмена после выбора напитка ---" << std::endl;
    a.coin(40);
    a.choice(1);
    std::cout << "Выбран чай. Состояние: " << a.getStateName() << std::endl;
    a.cancel();
    std::cout << "Отмена. Состояние: " << a.getStateName() << std::endl;

    std::cout << "\n--- Сценарий 4: отмена на этапе внесения денег ---" << std::endl;
    a.coin(100);
    std::cout << "Внесено 100 руб. Состояние: " << a.getStateName() << std::endl;
    a.cancel();
    std::cout << "Отмена. Состояние: " << a.getStateName() << std::endl;

    std::cout << "\n--- Сценарий 5: покупка чая со сдачей ---" << std::endl;
    a.coin(50);
    a.choice(1);
    if (a.check()) {
        a.cook();
        a.finish();
    }
    std::cout << "Состояние: " << a.getStateName() << std::endl;

    std::cout << "\n--- Выключение автомата ---" << std::endl;
    a.off();
    std::cout << "Состояние: " << a.getStateName() << std::endl;

    return 0;
}
