// Copyright 2026 Upi52
#include "Automata.h"
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

Automata::Automata() {
    cash = 0;
    state = OFF;
    selectedDrink = -1;
    std::ifstream file("menu.txt");
    if (file.is_open()) {
        std::string name;
        int price;
        while (file >> name >> price) {
            menu.push_back(name);
            prices.push_back(price);
        }
    }
    if (menu.empty()) {
        menu   = {"Кофе", "Чай", "Молоко", "Какао"};
        prices = {50,      30,    25,        40};
    }
}

void Automata::on() {
    if (state == OFF)
        state = WAIT;
}

void Automata::off() {
    if (state == WAIT)
        state = OFF;
}

void Automata::coin(int amount) {
    if ((state == WAIT || state == ACCEPT) && amount > 0) {
        cash += amount;
        state = ACCEPT;
    }
}

std::vector<std::string> Automata::getMenu() {
    return menu;
}

STATES Automata::getState() {
    return state;
}

std::string Automata::getStateName() {
    switch (state) {
        case OFF:    return "OFF";
        case WAIT:   return "WAIT";
        case ACCEPT: return "ACCEPT";
        case CHECK:  return "CHECK";
        case COOK:   return "COOK";
        default:     return "UNKNOWN";
    }
}

void Automata::choice(int item) {
    if (state == ACCEPT) {
        if (item >= 0 && item < static_cast<int>(menu.size())) {
            selectedDrink = item;
            state = CHECK;
        }
    }
}

bool Automata::check() {
    if (state == CHECK)
        return cash >= prices[selectedDrink];
    return false;
}

void Automata::cancel() {
    if (state == ACCEPT || state == CHECK) {
        std::cout << "Возврат средств: " << cash << " руб." << std::endl;
        cash = 0;
        selectedDrink = -1;
        state = WAIT;
    }
}

void Automata::cook() {
    if (state == CHECK && check())
        state = COOK;
}

void Automata::finish() {
    if (state == COOK) {
        cash -= prices[selectedDrink];
        std::cout << menu[selectedDrink] << " готов! Сдача: "
                  << cash << " руб." << std::endl;
        cash = 0;
        selectedDrink = -1;
        state = WAIT;
    }
}
