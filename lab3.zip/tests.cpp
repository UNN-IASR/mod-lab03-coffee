// Copyright 2026 Upi52
#include <gtest/gtest.h>
#include "Automata.h"

TEST(AutomataTest, InitialStateIsOff) {
    Automata a;
    EXPECT_EQ(a.getState(), OFF);
    EXPECT_EQ(a.cash, 0);
}

TEST(AutomataTest, OnChangesStateToWait) {
    Automata a;
    a.on();
    EXPECT_EQ(a.getState(), WAIT);
}

TEST(AutomataTest, OnIgnoredIfAlreadyOn) {
    Automata a;
    a.on();
    a.on();
    EXPECT_EQ(a.getState(), WAIT);
}

TEST(AutomataTest, OffChangesStateToOff) {
    Automata a;
    a.on();
    a.off();
    EXPECT_EQ(a.getState(), OFF);
}

TEST(AutomataTest, OffIgnoredIfNotInWait) {
    Automata a;
    a.off();
    EXPECT_EQ(a.getState(), OFF);
}

TEST(AutomataTest, CoinChangesStateToAccept) {
    Automata a;
    a.on();
    a.coin(20);
    EXPECT_EQ(a.getState(), ACCEPT);
}

TEST(AutomataTest, CoinAddsCash) {
    Automata a;
    a.on();
    a.coin(20);
    a.coin(15);
    EXPECT_EQ(a.cash, 35);
}

TEST(AutomataTest, CoinIgnoredWhenOff) {
    Automata a;
    a.coin(50);
    EXPECT_EQ(a.cash, 0);
    EXPECT_EQ(a.getState(), OFF);
}

TEST(AutomataTest, CoinIgnoredOnNonPositiveAmount) {
    Automata a;
    a.on();
    a.coin(0);
    a.coin(-10);
    EXPECT_EQ(a.cash, 0);
    EXPECT_EQ(a.getState(), WAIT);
}

TEST(AutomataTest, ChoiceChangesStateToCheck) {
    Automata a;
    a.on();
    a.coin(30);
    a.choice(0);
    EXPECT_EQ(a.getState(), CHECK);
}

TEST(AutomataTest, ChoiceIgnoredOnInvalidIndex) {
    Automata a;
    a.on();
    a.coin(30);
    a.choice(999);
    EXPECT_EQ(a.getState(), ACCEPT);
}

TEST(AutomataTest, CheckReturnsTrueWhenEnoughCash) {
    Automata a;
    a.on();
    a.coin(50);
    a.choice(0);
    EXPECT_TRUE(a.check());
}

TEST(AutomataTest, CheckReturnsFalseWhenNotEnoughCash) {
    Automata a;
    a.on();
    a.coin(10);
    a.choice(0);
    EXPECT_FALSE(a.check());
}

TEST(AutomataTest, CheckReturnsFalseWhenNotInCheckState) {
    Automata a;
    a.on();
    EXPECT_FALSE(a.check());
}

TEST(AutomataTest, CookChangesStateToCook) {
    Automata a;
    a.on();
    a.coin(50);
    a.choice(0);
    a.cook();
    EXPECT_EQ(a.getState(), COOK);
}

TEST(AutomataTest, CookIgnoredIfNotEnoughCash) {
    Automata a;
    a.on();
    a.coin(10);
    a.choice(0);
    a.cook();
    EXPECT_EQ(a.getState(), CHECK);
}

TEST(AutomataTest, FinishChangesStateToWait) {
    Automata a;
    a.on();
    a.coin(50);
    a.choice(0);
    a.cook();
    a.finish();
    EXPECT_EQ(a.getState(), WAIT);
    EXPECT_EQ(a.cash, 0);
}

TEST(AutomataTest, FinishGivesCorrectChange) {
    Automata a;
    a.on();
    a.coin(50);
    a.choice(1);
    a.cook();
    a.finish();
    EXPECT_EQ(a.cash, 0);
}

TEST(AutomataTest, CancelFromAcceptResetsToWait) {
    Automata a;
    a.on();
    a.coin(20);
    a.cancel();
    EXPECT_EQ(a.getState(), WAIT);
    EXPECT_EQ(a.cash, 0);
}

TEST(AutomataTest, CancelFromCheckResetsToWait) {
    Automata a;
    a.on();
    a.coin(20);
    a.choice(0);
    EXPECT_EQ(a.getState(), CHECK);
    a.cancel();
    EXPECT_EQ(a.getState(), WAIT);
    EXPECT_EQ(a.cash, 0);
}

TEST(AutomataTest, FullSessionCanRepeat) {
    Automata a;
    a.on();
    for (int i = 0; i < 2; ++i) {
        a.coin(50);
        a.choice(1);
        a.cook();
        a.finish();
    }
    EXPECT_EQ(a.getState(), WAIT);
}
